<?php
////////////////////////////////////////////////////////////////////////////////
//BOCA Online Contest Administrator
//    Copyright (C) 2003-2012 by BOCA Development Team (bocasystem@gmail.com)
//
//    This program is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//    You should have received a copy of the GNU General Public License
//    along with this program.  If not, see <http://www.gnu.org/licenses/>.
////////////////////////////////////////////////////////////////////////////////
// Last modified 05/aug/2012 by cassio@ime.usp.br
ob_start();
header ("Expires: " . gmdate("D, d M Y H:i:s") . " GMT");
header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header ("Cache-Control: no-cache, must-revalidate");
header ("Pragma: no-cache");
header ("Content-Type: text/html; charset=utf-8");
session_start();
ob_end_flush();
require_once('../version.php');

require_once("../globals.php");
require_once("../db.php");

echo "<html><head><title>System's Page</title>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
echo "<link rel=stylesheet href=\"../Css.php\" type=\"text/css\">\n";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/contest.css\">\n";

//echo "<meta http-equiv=\"refresh\" content=\"60\" />";
if(!ValidSession()) {
	InvalidSession("system/index.php");
        ForceLoad("../index.php");
}
if($_SESSION["usertable"]["usertype"] != "system") {
	IntrusionNotify("system/index.php");
        ForceLoad("../index.php");
}


echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/main.css\">";
echo "<link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.8.1/css/all.css\" integrity=\"sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf\" crossorigin=\"anonymous\">";
echo "<script src=\"../js/jquery.min.js\"></script>";
echo "<script type=\"text/JavaScript\" src=\"../js/main.js\"></script>";











echo "<div id=\"header\">

<div class=\"menuDropDown\">
<button class=\"menuDropBtn\"><i class=\"fa fa-bars fa-lg fa-fw\" aria-hidden=\"true\"></i></button>
<div id=\"menuDropDownList\" class=\"menuDropBtn-Content\">
<a href=\"index.php\"><i class=\"fa fa-home fa-lg fa-fw\" aria-hidden=\"true\"></i>&nbsp;Home</a>
<a href=\"contest.php\"><i class=\"fa fa-medal fa-lg fa-fw\" aria-hidden=\"true\"></i>&nbsp;Contest</a>
</div>
</div>

<div class=\"userDropDown\">
<button class=\"userDropBtn\">" . $_SESSION["usertable"]["userfullname"] . "&nbsp;<i class=\"fa fa-user fa-lg fa-fw\" aria-hidden=\"true\"></i></button>
<div id=\"userDropDownList\" class=\"userDropBtn-Content\">
<a href=\"option.php\">Options</a>
<a href=\"../index.php\">Logout</a>
</div>
</div>

</div>";










?>
